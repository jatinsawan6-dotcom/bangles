import { useState, useEffect } from 'react';
import { Search, User, Heart, ShoppingCart, Menu, X } from 'lucide-react';

const navLinks = [
  { name: 'Home', href: '#' },
  { name: 'Bangles', href: '#products' },
  { name: 'Categories', href: '#categories' },
  { name: 'New Arrivals', href: '#products' },
  { name: 'About', href: '#footer' },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [cartCount] = useState(2);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    setIsMobileMenuOpen(false);
    if (href === '#') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white shadow-nav py-3'
            : 'bg-transparent py-5'
        }`}
        style={{ top: isScrolled ? 0 : '40px' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#" onClick={(e) => { e.preventDefault(); scrollToSection('#'); }} className="flex flex-col items-start">
              <span className="font-playfair text-2xl sm:text-3xl font-bold leading-tight">
                <span className="text-gold">Sona</span>
                <span className={isScrolled ? 'text-charcoal' : 'text-white'}>Chudi</span>
              </span>
              <span className={`text-[10px] uppercase tracking-[0.2em] -mt-0.5 ${isScrolled ? 'text-gray-500' : 'text-white/70'}`}>
                The Royal Bangles Collection
              </span>
            </a>

            {/* Desktop Nav Links */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                  className={`relative text-sm font-medium transition-colors duration-300 group ${
                    isScrolled ? 'text-charcoal hover:text-gold' : 'text-white/90 hover:text-gold'
                  }`}
                >
                  {link.name}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full" />
                </a>
              ))}
            </div>

            {/* Right Icons */}
            <div className="flex items-center gap-4">
              <button className={`transition-all duration-300 hover:scale-110 ${isScrolled ? 'text-charcoal hover:text-gold' : 'text-white/90 hover:text-gold'}`}>
                <Search size={20} strokeWidth={1.5} />
              </button>
              <button className={`hidden sm:block transition-all duration-300 hover:scale-110 ${isScrolled ? 'text-charcoal hover:text-gold' : 'text-white/90 hover:text-gold'}`}>
                <User size={20} strokeWidth={1.5} />
              </button>
              <button className={`hidden sm:block transition-all duration-300 hover:scale-110 ${isScrolled ? 'text-charcoal hover:text-gold' : 'text-white/90 hover:text-gold'}`}>
                <Heart size={20} strokeWidth={1.5} />
              </button>
              <button className={`relative transition-all duration-300 hover:scale-110 ${isScrolled ? 'text-charcoal hover:text-gold' : 'text-white/90 hover:text-gold'}`}>
                <ShoppingCart size={20} strokeWidth={1.5} />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 w-5 h-5 bg-badge-red text-white text-xs rounded-full flex items-center justify-center font-semibold">
                    {cartCount}
                  </span>
                )}
              </button>
              <button
                className={`lg:hidden transition-colors ${isScrolled ? 'text-charcoal' : 'text-white'}`}
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 transition-all duration-300 lg:hidden ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileMenuOpen(false)} />
        <div
          className={`absolute right-0 top-0 h-full w-72 bg-white shadow-xl transition-transform duration-300 ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="p-6 pt-20">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                className="block py-3 text-lg font-medium text-charcoal hover:text-gold border-b border-gray-100 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
