import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const categories = [
  { name: 'Traditional Gold', count: 48, image: '/images/cat-traditional.jpg' },
  { name: 'Bridal Kangan', count: 32, image: '/images/cat-bridal.jpg' },
  { name: 'Daily Wear', count: 56, image: '/images/cat-daily.jpg' },
  { name: 'Stone Studded', count: 24, image: '/images/cat-stone.jpg' },
  { name: 'Rose Gold', count: 18, image: '/images/cat-rose.jpg' },
  { name: 'Antique Finish', count: 22, image: '/images/cat-antique.jpg' },
];

export default function Categories() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.category-card', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
        opacity: 0,
        y: 40,
        stagger: 0.1,
        duration: 0.6,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToProducts = () => {
    const element = document.querySelector('#products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="categories" ref={sectionRef} className="w-full bg-white py-20 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="section-badge mb-4 inline-block">Categories</span>
          <h2 className="font-playfair text-3xl sm:text-4xl font-bold text-charcoal mt-4">
            Shop by Style
          </h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
          {categories.map((cat) => (
            <button
              key={cat.name}
              onClick={scrollToProducts}
              className="category-card group text-left"
            >
              <div className="relative overflow-hidden rounded-lg aspect-square mb-3">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
              </div>
              <h3 className="text-sm sm:text-base font-semibold text-charcoal group-hover:text-gold transition-colors duration-300 text-center">
                {cat.name}
              </h3>
              <p className="text-xs text-gray-500 text-center mt-1">{cat.count} Designs</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
