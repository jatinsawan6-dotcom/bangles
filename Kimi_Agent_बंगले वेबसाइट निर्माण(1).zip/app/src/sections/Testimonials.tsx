import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Star, Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    name: 'Priya Sharma',
    location: 'Mumbai',
    rating: 5,
    text: 'The quality of these bangles is amazing! I\'ve been wearing them for 3 months and they still shine like new. Perfect for daily wear.',
  },
  {
    name: 'Anjali Patel',
    location: 'Ahmedabad',
    rating: 5,
    text: 'Bought the bridal set for my sister\'s wedding. Everyone thought they were real gold! Incredible craftsmanship at this price.',
  },
  {
    name: 'Meera Reddy',
    location: 'Hyderabad',
    rating: 5,
    text: 'Fast delivery and beautiful packaging. The anti-tarnish feature really works. I\'m ordering more for my cousins!',
  },
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.testimonial-card', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
        opacity: 0,
        y: 40,
        stagger: 0.15,
        duration: 0.7,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="w-full maroon-gradient py-20 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="font-playfair text-3xl sm:text-4xl font-bold text-white">
            What Our Customers Say
          </h2>
          <p className="text-white/60 mt-3 text-sm sm:text-base">
            Real reviews from 50,000+ happy customers
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="testimonial-card bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 sm:p-8 transition-all duration-300 hover:-translate-y-1 hover:border-white/40"
            >
              <Quote size={24} className="text-gold mb-4" />

              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < t.rating ? 'fill-gold text-gold' : 'text-white/30'}
                  />
                ))}
              </div>

              <p className="text-white/90 text-sm sm:text-base leading-relaxed mb-6 italic">
                "{t.text}"
              </p>

              <div>
                <p className="text-white font-semibold text-sm">{t.name}</p>
                <p className="text-white/60 text-xs">{t.location}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
