import { useState } from 'react';
import { X } from 'lucide-react';

export default function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="w-full h-10 bg-[#111111] flex items-center justify-center relative">
      <div className="overflow-hidden w-full">
        <div className="flex animate-marquee whitespace-nowrap hover:[animation-play-state:paused]">
          {[...Array(2)].map((_, i) => (
            <span key={i} className="flex items-center mx-4">
              <span className="text-white text-xs sm:text-sm font-medium mx-6">
                <span className="text-gold font-semibold">FREE</span> Shipping on Orders Above ₹999
              </span>
              <span className="text-gold mx-2">✦</span>
              <span className="text-white text-xs sm:text-sm font-medium mx-6">
                <span className="text-gold font-semibold">Buy 1 Get 1 Free</span> on All Bangles
              </span>
              <span className="text-gold mx-2">✦</span>
              <span className="text-white text-xs sm:text-sm font-medium mx-6">
                Cash on Delivery <span className="text-gold">Available</span>
              </span>
              <span className="text-gold mx-2">✦</span>
              <span className="text-white text-xs sm:text-sm font-medium mx-6">
                <span className="text-gold font-semibold">Anti-Tarnish</span> Guaranteed
              </span>
              <span className="text-gold mx-2">✦</span>
            </span>
          ))}
        </div>
      </div>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-4 text-white/60 hover:text-white transition-colors"
      >
        <X size={16} />
      </button>
    </div>
  );
}
