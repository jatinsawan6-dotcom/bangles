import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.newsletter-content', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 85%',
        },
        opacity: 0,
        y: 30,
        duration: 0.7,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setTimeout(() => {
        setSubscribed(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <section ref={sectionRef} className="w-full gold-gradient py-16 sm:py-20">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="newsletter-content text-center">
          <h2 className="font-playfair text-2xl sm:text-3xl md:text-4xl font-bold text-charcoal mb-3">
            Get 15% Off Your First Order
          </h2>
          <p className="text-charcoal-light text-sm sm:text-base mb-8 max-w-md mx-auto">
            Subscribe for exclusive deals, new arrivals, and festive offers.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <div className="flex-1 relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="w-full px-5 py-4 rounded-lg bg-white text-charcoal placeholder:text-gray-400 border-2 border-transparent focus:border-gold focus:outline-none transition-all duration-300"
                disabled={subscribed}
              />
            </div>
            <button
              type="submit"
              disabled={subscribed}
              className={`px-6 py-4 rounded-lg font-semibold text-sm uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-2 ${
                subscribed
                  ? 'bg-badge-green text-white'
                  : 'bg-maroon text-white hover:bg-maroon-dark'
              }`}
            >
              {subscribed ? (
                <>
                  <Check size={18} />
                  Subscribed!
                </>
              ) : (
                <>
                  Subscribe
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <p className="text-charcoal-light/70 text-xs mt-4">
            No spam, unsubscribe anytime.
          </p>
        </div>
      </div>
    </section>
  );
}
