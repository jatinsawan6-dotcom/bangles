import { Instagram, Facebook, MessageCircle } from 'lucide-react';

const quickLinks = [
  { name: 'Home', href: '#' },
  { name: 'Shop All', href: '#products' },
  { name: 'New Arrivals', href: '#products' },
  { name: 'Bestsellers', href: '#products' },
  { name: 'Track Order', href: '#' },
];

const categories = [
  { name: 'Traditional Bangles', href: '#categories' },
  { name: 'Bridal Kangan', href: '#categories' },
  { name: 'Daily Wear', href: '#categories' },
  { name: 'Stone Studded', href: '#categories' },
  { name: 'Rose Gold', href: '#categories' },
  { name: 'Antique', href: '#categories' },
];

export default function Footer() {
  const scrollToSection = (href: string) => {
    if (href === '#') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="footer" className="w-full bg-[#1A1A1A] pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Column */}
          <div>
            <a href="#" onClick={(e) => { e.preventDefault(); scrollToSection('#'); }}>
              <span className="font-playfair text-2xl font-bold text-gold">
                Sona<span className="text-white">Chudi</span>
              </span>
            </a>
            <p className="text-gray-400 text-sm mt-4 leading-relaxed">
              India's trusted destination for authentic, anti-tarnish gold plated bangles since 2018.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-gray-400 hover:text-gold hover:bg-white/20 transition-all duration-300"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-gray-400 hover:text-gold hover:bg-white/20 transition-all duration-300"
              >
                <Facebook size={18} />
              </a>
              <a
                href="https://wa.me/919876543210"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-gray-400 hover:text-[#25D366] hover:bg-white/20 transition-all duration-300"
              >
                <MessageCircle size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    onClick={(e) => { e.preventDefault(); scrollToSection(link.href); }}
                    className="text-gray-400 text-sm hover:text-gold transition-colors duration-300"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
              Categories
            </h4>
            <ul className="space-y-3">
              {categories.map((cat) => (
                <li key={cat.name}>
                  <a
                    href={cat.href}
                    onClick={(e) => { e.preventDefault(); scrollToSection(cat.href); }}
                    className="text-gray-400 text-sm hover:text-gold transition-colors duration-300"
                  >
                    {cat.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">
              Contact Us
            </h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li className="flex items-center gap-2">
                <MessageCircle size={14} className="text-gold shrink-0" />
                <span>WhatsApp: +91 98765 43210</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-gold">@</span>
                <span>care@sonachudi.com</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-gold">🕐</span>
                <span>Mon-Sat: 10AM - 7PM</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="border-t border-white/10 pt-6 pb-4">
          <div className="flex flex-wrap items-center justify-center gap-4 mb-4">
            {['UPI', 'COD', 'PayTM', 'Google Pay', 'PhonePe', 'Visa', 'Mastercard'].map((method) => (
              <span
                key={method}
                className="px-3 py-1.5 bg-white/5 rounded text-gray-400 text-xs font-medium"
              >
                {method}
              </span>
            ))}
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 pt-6 text-center">
          <p className="text-gray-500 text-xs sm:text-sm">
            © 2025 SonaChudi. All rights reserved. | Made with ❤️ in India
          </p>
        </div>
      </div>
    </footer>
  );
}
