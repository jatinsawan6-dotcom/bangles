import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export default function CountdownBanner() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 2, hours: 11, minutes: 45, seconds: 30 });
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { days, hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) {
          seconds = 59;
          minutes--;
        }
        if (minutes < 0) {
          minutes = 59;
          hours--;
        }
        if (hours < 0) {
          hours = 23;
          days--;
        }
        if (days < 0) {
          return { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
        return { days, hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.countdown-item', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 85%',
        },
        opacity: 0,
        y: 30,
        stagger: 0.1,
        duration: 0.6,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  const timeBoxes = [
    { label: 'Days', value: timeLeft.days },
    { label: 'Hours', value: timeLeft.hours },
    { label: 'Minutes', value: timeLeft.minutes },
    { label: 'Seconds', value: timeLeft.seconds },
  ];

  return (
    <section ref={sectionRef} className="w-full bg-cream py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-2xl sm:text-3xl font-bold text-charcoal mb-2 font-playfair">
          Flash Sale Ends In
        </h2>
        <p className="text-gray-500 text-sm mb-8">Hurry! Limited time offer on all bangles</p>

        <div className="flex items-center justify-center gap-3 sm:gap-4">
          {timeBoxes.map((box, index) => (
            <div key={box.label} className="countdown-item flex items-center gap-3 sm:gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-white border-2 border-gold rounded-lg flex flex-col items-center justify-center shadow-card">
                <span className="font-playfair text-xl sm:text-2xl md:text-3xl font-bold text-charcoal">
                  {formatNumber(box.value)}
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-wider mt-0.5">
                  {box.label}
                </span>
              </div>
              {index < timeBoxes.length - 1 && (
                <span className="text-gold text-xl sm:text-2xl font-bold">:</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
