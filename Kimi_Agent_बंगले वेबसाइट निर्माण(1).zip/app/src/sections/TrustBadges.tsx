import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Truck, Shield, RotateCcw, Phone } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const badges = [
  {
    icon: Truck,
    title: 'Free Shipping',
    description: 'Free delivery on orders above ₹999 across India',
  },
  {
    icon: Shield,
    title: 'Anti Tarnish',
    description: 'Premium gold plating with anti-tarnish guarantee',
  },
  {
    icon: RotateCcw,
    title: 'Easy Returns',
    description: '15-day hassle-free return and exchange policy',
  },
  {
    icon: Phone,
    title: 'COD Available',
    description: 'Cash on delivery available for all orders',
  },
];

export default function TrustBadges() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.trust-badge', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 85%',
        },
        opacity: 0,
        y: 30,
        stagger: 0.1,
        duration: 0.6,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="w-full bg-white py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10">
          {badges.map((badge) => (
            <div
              key={badge.title}
              className="trust-badge flex flex-col items-center text-center group"
            >
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110">
                <badge.icon size={28} className="text-gold" strokeWidth={1.5} />
              </div>
              <h3 className="text-base font-semibold text-charcoal mb-2">
                {badge.title}
              </h3>
              <p className="text-sm text-gray-500 leading-relaxed max-w-[220px]">
                {badge.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
