export default function MarqueeBar() {
  const messages = [
    '🔥 Buy 1 Get 1 Free on All Bangles 🔥',
    '🚚 FREE Shipping Above ₹999 🚚',
    '✨ Anti-Tarnish Guaranteed ✨',
    '💰 Cash on Delivery Available 💰',
    '⭐ 50,000+ Happy Customers ⭐',
    '🎁 Free Gift Box with Every Order 🎁',
  ];

  return (
    <div className="w-full bg-maroon py-3 overflow-hidden">
      <div className="flex animate-marquee hover:[animation-play-state:paused]">
        {[...Array(4)].map((_, setIndex) => (
          <div key={setIndex} className="flex items-center shrink-0">
            {messages.map((msg, i) => (
              <span key={`${setIndex}-${i}`} className="flex items-center shrink-0">
                <span className="text-white text-sm font-medium whitespace-nowrap px-6">
                  {msg}
                </span>
                <span className="text-gold text-lg shrink-0">✦</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
