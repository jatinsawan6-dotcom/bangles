import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Star, Plus, Check, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Product {
  id: number;
  name: string;
  image: string;
  price: number;
  mrp: number;
  rating: number;
  reviews: number;
  badge?: string;
  antiTarnish: boolean;
}

const products: Product[] = [
  {
    id: 1,
    name: 'Rajwadi Gold Bangle Set (2pcs)',
    image: '/images/prod-1.jpg',
    price: 999,
    mrp: 1999,
    rating: 4.8,
    reviews: 156,
    badge: '50% OFF',
    antiTarnish: true,
  },
  {
    id: 2,
    name: 'Kundan Studded Kangan Set',
    image: '/images/prod-2.jpg',
    price: 1299,
    mrp: 2599,
    rating: 4.7,
    reviews: 98,
    badge: 'HOT',
    antiTarnish: true,
  },
  {
    id: 3,
    name: 'Daily Wear Simple Bangles',
    image: '/images/prod-3.jpg',
    price: 599,
    mrp: 1199,
    rating: 4.9,
    reviews: 234,
    badge: 'BESTSELLER',
    antiTarnish: true,
  },
  {
    id: 4,
    name: 'Bridal Chura Red Gold Set',
    image: '/images/prod-4.jpg',
    price: 1799,
    mrp: 3599,
    rating: 4.6,
    reviews: 87,
    badge: '50% OFF',
    antiTarnish: true,
  },
  {
    id: 5,
    name: 'Rose Gold Modern Bangle',
    image: '/images/prod-5.jpg',
    price: 899,
    mrp: 1799,
    rating: 4.8,
    reviews: 145,
    badge: 'NEW',
    antiTarnish: true,
  },
  {
    id: 6,
    name: 'Antique Oxidized Kangan',
    image: '/images/prod-6.jpg',
    price: 799,
    mrp: 1599,
    rating: 4.5,
    reviews: 67,
    badge: '50% OFF',
    antiTarnish: true,
  },
  {
    id: 7,
    name: 'Diamond Look Bangles Set',
    image: '/images/prod-7.jpg',
    price: 1099,
    mrp: 2199,
    rating: 4.7,
    reviews: 112,
    badge: 'HOT',
    antiTarnish: true,
  },
  {
    id: 8,
    name: 'White Metal Classic Bangles',
    image: '/images/prod-8.jpg',
    price: 499,
    mrp: 999,
    rating: 4.6,
    reviews: 189,
    badge: '50% OFF',
    antiTarnish: true,
  },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          size={14}
          className={i < Math.floor(rating) ? 'star-filled fill-gold' : 'star-empty'}
        />
      ))}
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const discount = Math.round(((product.mrp - product.price) / product.mrp) * 100);

  return (
    <div className="product-card group">
      {/* Image */}
      <div className="relative aspect-square overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.antiTarnish && (
            <span className="px-2 py-1 bg-badge-green text-white text-[10px] font-semibold rounded uppercase tracking-wider">
              Anti Tarnish
            </span>
          )}
        </div>
        {product.badge && (
          <div className="absolute top-3 right-3">
            <span className={`px-2 py-1 text-white text-[10px] font-semibold rounded uppercase tracking-wider ${
              product.badge === 'HOT' || product.badge === 'NEW' || product.badge === 'BESTSELLER'
                ? 'bg-badge-red'
                : 'bg-gold'
            }`}>
              {product.badge}
            </span>
          </div>
        )}

        {/* Quick Add Button */}
        <button
          onClick={handleAddToCart}
          className={`absolute bottom-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-md ${
            added
              ? 'bg-badge-green text-white scale-110'
              : 'bg-white text-charcoal opacity-0 group-hover:opacity-100 hover:bg-gold hover:text-white'
          }`}
        >
          {added ? <Check size={18} /> : <Plus size={18} />}
        </button>

        {/* Discount Badge */}
        {discount > 0 && (
          <div className="absolute bottom-3 left-3">
            <span className="px-2 py-1 bg-maroon text-white text-[10px] font-bold rounded">
              {discount}% OFF
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 text-center">
        <h3 className="text-sm font-semibold text-charcoal line-clamp-2 min-h-[40px]">
          {product.name}
        </h3>

        <div className="flex items-center justify-center gap-2 mt-2">
          <StarRating rating={product.rating} />
          <span className="text-xs text-gray-500">({product.reviews})</span>
        </div>

        <div className="flex items-center justify-center gap-2 mt-2">
          <span className="text-lg font-bold text-badge-red">
            ₹{product.price.toLocaleString('en-IN')}
          </span>
          <span className="text-sm text-gray-400 line-through">
            ₹{product.mrp.toLocaleString('en-IN')}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function FeaturedProducts() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.product-card', {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
        opacity: 0,
        y: 40,
        stagger: 0.08,
        duration: 0.6,
        ease: 'power3.out',
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section id="products" ref={sectionRef} className="w-full bg-cream py-20 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-12 gap-4">
          <div>
            <span className="section-badge mb-4 inline-block">Bestsellers</span>
            <h2 className="font-playfair text-3xl sm:text-4xl font-bold text-charcoal mt-4">
              Our Most Loved Bangles
            </h2>
          </div>
          <button className="text-gold font-semibold text-sm flex items-center gap-1 hover:gap-2 transition-all group">
            View All Products
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
