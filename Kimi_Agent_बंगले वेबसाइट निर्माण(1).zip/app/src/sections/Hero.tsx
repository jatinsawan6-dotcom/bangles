import { useEffect, useRef } from 'react';
import { Star, ArrowRight } from 'lucide-react';
import gsap from 'gsap';

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
      tl.from('.hero-badge', { opacity: 0, y: 20, duration: 0.6, delay: 0.2 })
        .from('.hero-title', { opacity: 0, y: 30, scale: 0.95, duration: 0.8 }, '-=0.3')
        .from('.hero-subtitle', { opacity: 0, y: 20, duration: 0.6 }, '-=0.4')
        .from('.hero-cta', { opacity: 0, y: 20, duration: 0.6 }, '-=0.3')
        .from('.hero-trust', { opacity: 0, y: 15, duration: 0.5 }, '-=0.2');
    }, heroRef);

    return () => ctx.revert();
  }, []);

  const scrollToProducts = () => {
    const element = document.querySelector('#products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={heroRef}
      className="relative w-full min-h-[100vh] flex items-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Beautiful gold bangles"
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Content */}
      <div ref={contentRef} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 w-full">
        <div className="max-w-2xl">
          <div className="hero-badge section-badge mb-6 inline-flex items-center gap-2">
            <span className="text-gold">✨</span>
            FESTIVAL OF BANGLES
            <span className="text-gold">✨</span>
          </div>

          <h1 className="hero-title font-playfair text-4xl sm:text-5xl md:text-6xl font-bold text-white leading-tight mb-6">
            Adorn Your Wrists With{' '}
            <span className="text-gold">Royal Gold</span>
          </h1>

          <p className="hero-subtitle text-base sm:text-lg text-white/80 mb-8 max-w-lg leading-relaxed">
            1000+ Authentic Indian Bangles Designs | Anti-Tarnish Gold Plated | Free Shipping
          </p>

          <button
            onClick={scrollToProducts}
            className="hero-cta btn-primary text-base px-8 py-4 gap-2 group"
          >
            Shop Now - 50% OFF
            <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
          </button>

          <div className="hero-trust mt-8 flex items-center gap-3">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={16} className="star-filled fill-gold" />
              ))}
            </div>
            <span className="text-white/80 text-sm">
              Trusted by <span className="text-gold font-semibold">50,000+</span> Happy Customers
            </span>
          </div>
        </div>
      </div>

      {/* Floating Decorative Element */}
      <div className="hidden lg:block absolute right-20 top-1/2 -translate-y-1/2 z-10">
        <div className="animate-float">
          <div className="w-48 h-48 rounded-full bg-gold/10 backdrop-blur-sm border border-gold/30 flex items-center justify-center">
            <div className="w-36 h-36 rounded-full bg-gold/20 backdrop-blur-sm border border-gold/40 flex items-center justify-center">
              <span className="font-playfair text-3xl text-gold font-bold">50%</span>
            </div>
          </div>
          <p className="text-center text-white/70 text-sm mt-3 font-medium">OFF EVERYTHING</p>
        </div>
      </div>
    </section>
  );
}
