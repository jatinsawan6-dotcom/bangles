import AnnouncementBar from '../sections/AnnouncementBar';
import Navbar from '../sections/Navbar';
import Hero from '../sections/Hero';
import MarqueeBar from '../sections/MarqueeBar';
import CountdownBanner from '../sections/CountdownBanner';
import Categories from '../sections/Categories';
import FeaturedProducts from '../sections/FeaturedProducts';
import TrustBadges from '../sections/TrustBadges';
import Testimonials from '../sections/Testimonials';
import Newsletter from '../sections/Newsletter';
import Footer from '../sections/Footer';
import WhatsAppButton from '../sections/WhatsAppButton';

export default function Home() {
  return (
    <main className="min-h-screen bg-cream overflow-x-hidden">
      <AnnouncementBar />
      <Navbar />
      <Hero />
      <MarqueeBar />
      <CountdownBanner />
      <Categories />
      <FeaturedProducts />
      <TrustBadges />
      <Testimonials />
      <Newsletter />
      <Footer />
      <WhatsAppButton />
    </main>
  );
}
